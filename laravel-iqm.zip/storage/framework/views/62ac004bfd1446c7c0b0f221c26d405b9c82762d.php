<div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
    <!-- ============================================================== -->
    <!-- toggle and nav items -->
    <!-- ============================================================== -->
    <ul class="navbar-nav float-start me-auto">
        <li class="nav-item d-none d-lg-block"><a
                class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)"
                data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
        <!-- ============================================================== -->
        
    </ul>
    <!-- ============================================================== -->
    <!-- Right side toggle and nav items -->
    <!-- ============================================================== -->
    <ul class="navbar-nav float-end">
        <!-- ============================================================== -->
        <!-- Comment -->
        <!-- ============================================================== -->
        
        <!-- ============================================================== -->
        <!-- End Comment -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Messages -->
        <!-- ============================================================== -->
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle waves-effect waves-dark" href="#" id="2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                 <i class="font-24 mdi mdi-account-circle"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end mailbox animated bounceInDown" aria-labelledby="2">
                <ul class="list-style-none">
                    <li>
                        <div class="">
                            <!-- Message -->
                            <a href="/login/out" class="link border-top">
                                <div class="d-flex no-block align-items-center p-10">
                                    <span class="btn btn-danger btn-circle"><i
                                            class="ti-close"></i></span>
                                    <div class="ms-2">
                                        <h5 class="mb-0">Logout</h5>
                                        
                                    </div>
                                </div>
                            </a>
                            
                        </div>
                    </li>
                </ul>
            </ul>
        </li>
        <!-- ============================================================== -->
        <!-- End Messages -->
        <!-- ============================================================== -->

        <!-- ============================================================== -->
        <!-- User profile and search -->
        <!-- ============================================================== -->
        
        <!-- ============================================================== -->
        <!-- User profile and search -->
        <!-- ============================================================== -->
    </ul>
</div><?php /**PATH C:\Users\User\Documents\laravel-iqm\resources\views/navbar-collapse.blade.php ENDPATH**/ ?>