 <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js ')); ?>" ></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/extra-libs/sparkline/sparkline.js ')); ?>" ></script>
    <!--Wave Effects -->
    <script src="<?php echo e(asset('dist/js/waves.js ')); ?>" ></script>
    <!--Menu sidebar -->
    <script src="<?php echo e(asset('dist/js/sidebarmenu.js ')); ?>" ></script>
    <!--Custom JavaScript -->
    <script src="<?php echo e(asset('dist/js/custom.min.js ')); ?>" ></script>
    <!--This page JavaScript -->
    <!-- <script src="<?php echo e(asset('dist/js/pages/dashboards/dashboard1.js ')); ?>" ></script> -->
    <!-- Charts js Files -->
    <script src="<?php echo e(asset('assets/libs/flot/excanvas.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.pie.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.time.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.stack.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.crosshair.js ')); ?>" ></script>
    <script src="<?php echo e(asset('assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js ')); ?>" ></script>
    <script src="<?php echo e(asset('dist/js/pages/chart/chart-page-init.js ')); ?>" ></script><?php /**PATH C:\Users\User\Documents\adam-kasir\resources\views/jquery.blade.php ENDPATH**/ ?>