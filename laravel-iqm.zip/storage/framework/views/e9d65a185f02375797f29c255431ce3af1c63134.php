<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Matrix lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Matrix admin lite design, Matrix admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description"
        content="Matrix Admin Lite Free Version is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>IQM - Edit Ustadzah</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/favicon.png ')); ?>">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/libs/flot/css/float-chart.css ')); ?>"  rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/libs/select2/dist/css/select2.min.css ')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/libs/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css ')); ?>">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('dist/css/style.min.css ')); ?>"  rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <?php echo $__env->make('logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i
                            class="ti-menu ti-close"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                
                <?php echo $__env->make('navbar-collapse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php echo $__env->make('aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Edit Data Ustadzah / Ustadzah</h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales Cards  -->
                <!-- ============================================================== -->
                
                <!-- ============================================================== -->
                
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Recent comment and chats -->
                <!-- ============================================================== -->
                <?php if(session('gagal')): ?>
                    <div class="alert alert-danger" role="alert">
                        <h4 class="alert-heading">Gagal!</h4>
                        
                        <p class="mb-0"><?php echo e(session('gagal')); ?>.</p>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <!-- column -->
                    <div class="col-lg-12">
                        <div class="card">
                            <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="/ustadzah/update">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" class="form-control" id="fname" placeholder="" name="id" value="<?php echo e($data['id']); ?>">
                                <input type="hidden" class="form-control" id="fname" placeholder="" name="fileFoto" value="<?php echo e($data['foto']); ?>">
                                <input type="hidden" class="form-control" id="fname" placeholder="" name="fileSk" value="<?php echo e($data['sk']); ?>">
                                <input type="hidden" class="form-control" id="fname" placeholder="" name="fileIj" value="<?php echo e($data['ijazah']); ?>">
                                <div class="card-body">
                                    <h4 class="card-title">Info Ustadz/ Ustadzah</h4>
                                    <div class="p-2 mb-2" style="text-align: center"><img src="/foto-ustadzah/<?php echo e($data['foto']); ?>" alt="user" 
                                        class="rounded-circle" width="120" height="120"></div>
                                    <div class="form-group row">
                                        <label for="fname"
                                            class="col-sm-2 text-end control-label col-form-label">Nama </label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="fname"
                                                placeholder="" name="nama" value="<?php echo e($data['nama']); ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Kontak</label>
                                        <div class="col-md-9">  
                                            <input type="text" class="form-control" id="fname"
                                                placeholder="" name="kontak" value="<?php echo e($data['kontak']); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Pendidikan Terkahir</label>
                                        <div class="col-md-9">
                                            <select class="select2 form-select shadow-none"
                                                style="width: 100%; height:36px;" name="pendidikan_akhir" id="pendidikan_akhir">
                                              
                                                <optgroup label="Pilih Pendidikan">
                                                    <option value="1" <?php if($data['pendidikan_akhir'] == 1): ?> selected <?php endif; ?>> SMA/SMK </option> 
                                                    <option value="2" <?php if($data['pendidikan_akhir'] == 2): ?> selected <?php endif; ?>> S1 </option> 
                                                    <option value="3" <?php if($data['pendidikan_akhir'] == 3): ?> selected <?php endif; ?>> S2 </option> 
                                                    <option value="4" <?php if($data['pendidikan_akhir'] == 4): ?> selected <?php endif; ?>> S2 </option> 
                                                </optgroup>
                                                
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Sekolah / Kampus </label>
                                        <div class="col-md-9">  
                                            <input type="text" class="form-control" id="fname"
                                                placeholder="" name="lulusan" value="<?php echo e($data['lulusan']); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Jurusan </label>
                                        <div class="col-md-9">  
                                            <input type="text" class="form-control" id="fname"
                                                placeholder="" name="jurusan" value="<?php echo e($data['jurusan']); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Ijazah Akhir (pdf, png)</label>
                                        <div class="col-md-9">  
                                            <input type="file" class="form-control" id="fname"
                                                placeholder="" name="ijazah" accept=".pdf,.png">
                                        </div>
                                        <div class="col-md-1">  
                                            <a href="/ijazah-ustadzah/<?php echo e($data['ijazah']); ?>" class="btn btn-outline-info"><i class="fa fa-download"></i> </a>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Alamat</label>
                                        <div class="col-md-9">  
                                            <textarea class="form-control" name="alamat"><?php echo e($data['alamat']); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Foto (jpg, jpeg, png)</label>
                                        <div class="col-md-9">  
                                            <input type="file" class="form-control" id="fname"
                                                placeholder="" name="foto" accept=".jpg,.png">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">Kartu Keluarga (pdf, png)</label>
                                        <div class="col-md-9">  
                                            <input type="file" class="form-control" id="fname"
                                                placeholder="" name="kk" accept=".pdf,.png">
                                        </div>
                                        <div class="col-md-1">  
                                            <a href="/kk-ustadzah/<?php echo e($data['kk']); ?>" class="btn btn-outline-info"><i class="fa fa-download"></i> </a>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">KTP (pdf, png)</label>
                                        <div class="col-md-9">  
                                            <input type="file" class="form-control" id="fname"
                                                placeholder="" name="ktp" accept=".pdf,.png">
                                        </div>
                                        <div class="col-md-1">  
                                            <a href="/ktp-ustadzah/<?php echo e($data['ktp']); ?>" class="btn btn-outline-info"><i class="fa fa-download"></i> </a>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2  text-end control-label col-form-label">SK Guru (pdf, png)</label>
                                        <div class="col-md-9">  
                                            <input type="file" class="form-control" id="fname"
                                                placeholder="" name="sk" accept=".pdf,.png">
                                        </div>
                                        <div class="col-md-1">  
                                            <a href="/sk-ustadzah/<?php echo e($data['sk']); ?>" class="btn btn-outline-info"><i class="fa fa-download"></i> </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="border-top">
                                    <div class="card-body">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                </div>
                <!-- ============================================================== -->
                <!-- Recent comment and chats -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                Developed by SIT Insan Qur'ani Mulia Bima, Template  by <a href="https://www.wrappixel.com">WrapPixel</a> 
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
   <?php echo $__env->make('jquery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <script src="<?php echo e(asset('assets/libs/select2/dist/js/select2.full.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/libs/select2/dist/js/select2.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
         $(".select2").select2();
         jQuery('.mydatepicker').datepicker();
         jQuery('#datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });
        $('#tgl_lahir').val("<?php echo e(\Carbon\Carbon::parse($data['tanggal_lahir'])->format('m/d/Y')); ?>");
        $('#pendidikan_akhir').val("<?php echo e($data['pendidikan_akhir']); ?>");
    </script>

</body>

</html><?php /**PATH C:\Users\User\Documents\laravel-iqm\resources\views/ustadzah/edit.blade.php ENDPATH**/ ?>