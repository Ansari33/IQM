<a class="navbar-brand" href="/">
    <!-- Logo icon -->
    <b class="logo-icon ps-2">
        <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
        <!-- Dark Logo icon -->
        <img src="<?php echo e(asset('assets/images/iqm.png ')); ?>" alt="homepage" class="light-logo" style="width: 50px" />

    </b>
    <!--End Logo icon -->
    <!-- Logo text -->
    <span class="logo-text mt-1" >
        <!-- dark Logo text -->
        
        <span style="font-size: 20px; font-weight: bold;" class=""> SIT</span>  IQM Bima

    </span>
    <!-- Logo icon -->
    <!-- <b class="logo-icon"> -->
    <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
    <!-- Dark Logo icon -->
    <!-- <img src="<?php echo e(asset('assets/images/logo-text.png ')); ?>" alt="homepage" class="light-logo" /> -->

    <!-- </b> -->
    <!--End Logo icon -->
</a><?php /**PATH G:\C DOC\laravel-iqm\resources\views/logo.blade.php ENDPATH**/ ?>