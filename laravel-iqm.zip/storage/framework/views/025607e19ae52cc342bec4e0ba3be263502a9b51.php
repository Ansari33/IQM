
<aside class="left-sidebar" data-sidebarbg="skin5">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav" class="pt-4">
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="/" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span
                            class="hide-menu">Dashboard</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="/stok" aria-expanded="false"><i class="mdi mdi-chart-bar"></i><span
                            class="hide-menu">Stok</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="/merk" aria-expanded="false"><i class="mdi mdi-chart-bubble"></i><span
                            class="hide-menu">Merk</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="/jenis" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span
                            class="hide-menu">Jenis</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="/pembelian" aria-expanded="false"><i class="mdi mdi-cart-outline"></i><span
                            class="hide-menu">Pembelian</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                    href="/penjualan" aria-expanded="false"><i class="mdi mdi-cash"></i><span
                        class="hide-menu">Penjualan</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                    href="/laporan" aria-expanded="false"><i class="mdi mdi-book"></i><span
                        class="hide-menu">Laporan</span></a></li>            
                
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<?php /**PATH C:\Users\User\Documents\adam-kasir\resources\views/aside.blade.php ENDPATH**/ ?>