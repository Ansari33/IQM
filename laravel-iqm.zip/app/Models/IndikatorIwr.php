<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IndikatorIwr extends Model
{
    use HasFactory;

    protected $table = 'indikator_iwr';
    protected $guarded = [];

    

}
